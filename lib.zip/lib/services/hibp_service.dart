import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;

class HIBPService {
  static Future<int> checkPassword(String password) async {
    try {
      final bytes = utf8.encode(password);
      final hash = sha1.convert(bytes).toString().toUpperCase();
      final prefix = hash.substring(0, 5);
      final suffix = hash.substring(5);

      final url = Uri.parse('https://api.pwnedpasswords.com/range/$prefix');
      final response = await http.get(url, headers: {'User-Agent': 'VaultX-Security-App'});

      if (response.statusCode == 200) {
        final lines = LineSplitter.split(response.body);
        for (var line in lines) {
          final parts = line.split(':');
          if (parts[0] == suffix) return int.parse(parts[1]); 
        }
      }
      return 0; 
    } catch (e) {
      print("HIBP Error: $e");
      return 0; 
    }
  }
}